import React from "react";

const UsuariosPage = () => {
  return (
    <h1>usuarios</h1>
  );
};

export default UsuariosPage;
