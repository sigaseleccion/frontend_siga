export { convocatoriaService } from './convocatoriaService';
export { aprendizService } from './aprendizService';
