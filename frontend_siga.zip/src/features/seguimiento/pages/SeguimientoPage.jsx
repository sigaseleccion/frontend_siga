// import React from "react";

// const SeguimientoPage = () => {
//   return (
//     <h1>Seguimiento</h1>
//   );
// };

// export default SeguimientoPage;


'use client';

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Navbar } from '@/shared/components/Navbar';
import { Button } from '@/shared/components/ui/button';
import { Card, CardContent } from '@/shared/components/ui/card';
import { Badge } from '@/shared/components/ui/badge';
import { Input } from '@/shared/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/shared/components/ui/select';
import {
  Search,
  BookOpen,
  Briefcase,
  Users,
  Edit2,
  Eye,
  History,
  AlertTriangle,
} from 'lucide-react';
import { useSeguimiento } from '../hooks/useSeguimiento';
import { EditCuotaModal, AprendicesIncompletosModal } from '../componentes';

const SeguimientoPage = () => {
  const navigate = useNavigate();
  const {
    aprendices,
    estadisticas,
    loading,
    filtros,
    actualizarFiltros,
    refetchEstadisticas,
  } = useSeguimiento();

  const [searchTerm, setSearchTerm] = useState('');
  const [etapaFilter, setEtapaFilter] = useState('todas');
  const [isEditCuotaOpen, setIsEditCuotaOpen] = useState(false);
  const [isIncompletosOpen, setIsIncompletosOpen] = useState(false);

  const handleSearch = (e) => {
    const value = e.target.value;
    setSearchTerm(value);
    actualizarFiltros({ busqueda: value });
  };

  const handleEtapaChange = (value) => {
    setEtapaFilter(value);
    actualizarFiltros({ etapa: value === 'todas' ? '' : value });
  };

  const formatDate = (dateString) => {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleDateString('es-ES', {
      day: 'numeric',
      month: 'numeric',
      year: 'numeric',
    });
  };

  const calcularDiasRestantes = (fechaFin) => {
    if (!fechaFin) return '-';
    const hoy = new Date();
    const fin = new Date(fechaFin);
    const diferencia = Math.ceil((fin - hoy) / (1000 * 60 * 60 * 24));
    return diferencia;
  };

  const getEtapaBadgeStyle = (etapa) => {
    switch (etapa) {
      case 'lectiva':
        return 'bg-blue-100 text-blue-700 hover:bg-blue-100';
      case 'productiva':
        return 'bg-purple-100 text-purple-700 hover:bg-purple-100';
      case 'finalizado':
        return 'bg-gray-100 text-gray-700 hover:bg-gray-100';
      default:
        return 'bg-gray-100 text-gray-700 hover:bg-gray-100';
    }
  };

  const getEtapaIcon = (etapa) => {
    switch (etapa) {
      case 'lectiva':
        return <BookOpen size={12} className="mr-1" />;
      case 'productiva':
        return <Briefcase size={12} className="mr-1" />;
      default:
        return null;
    }
  };

  const handleVerAprendiz = (aprendiz) => {
    // Navegar al detalle del aprendiz
    navigate(`/seguimiento/aprendiz/${aprendiz._id}`);
  };

  const handleEditarAprendiz = (aprendiz) => {
    // Navegar a editar aprendiz
    navigate(`/seguimiento/aprendiz/${aprendiz._id}/editar`);
  };

  return (
    <>
      <Navbar />
      <main className="ml-64 min-h-screen bg-gray-50">
        <div className="p-8">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Seguimiento</h1>
                <p className="text-gray-600 mt-1">
                  Monitoreo de aprendices en etapas lectiva y productiva
                </p>
              </div>
              <Button
                variant="outline"
                onClick={() => navigate('/seguimiento/historico')}
                className="flex items-center gap-2"
              >
                <History size={18} />
                Historico
              </Button>
            </div>
          </div>

          {/* Search and Filter */}
          <div className="flex items-center gap-4 mb-6">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Buscar aprendiz..."
                value={searchTerm}
                onChange={handleSearch}
                className="pl-10 bg-white border-gray-200"
              />
            </div>
            <Select value={etapaFilter} onValueChange={handleEtapaChange}>
              <SelectTrigger className="w-[200px] bg-white">
                <SelectValue placeholder="Todas las etapas" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todas">Todas las etapas</SelectItem>
                <SelectItem value="lectiva">Etapa Lectiva</SelectItem>
                <SelectItem value="productiva">Etapa Productiva</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {/* En Etapa Lectiva */}
            <Card className="border border-gray-200">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">En Etapa Lectiva</p>
                    <p className="text-3xl font-bold text-gray-900">
                      {estadisticas.enEtapaLectiva}
                    </p>
                  </div>
                  <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center">
                    <BookOpen className="text-blue-600" size={24} />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* En Etapa Productiva */}
            <Card className="border border-purple-200">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">En Etapa Productiva</p>
                    <p className="text-3xl font-bold text-gray-900">
                      {estadisticas.enEtapaProductiva}
                    </p>
                  </div>
                  <div className="w-12 h-12 bg-purple-50 rounded-lg flex items-center justify-center">
                    <Briefcase className="text-purple-600" size={24} />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Cuota de Aprendices */}
            <Card className="border border-gray-200">
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Cuota de Aprendices</p>
                    <p className="text-2xl font-bold text-gray-900">
                      Aprendices {estadisticas.cuota?.actual || 0}/{estadisticas.cuota?.maximo || 150}
                    </p>
                    {estadisticas.aprendicesIncompletos > 0 && (
                      <button
                        onClick={() => setIsIncompletosOpen(true)}
                        className="flex items-center gap-1 text-amber-600 text-sm mt-2 hover:underline"
                      >
                        <AlertTriangle size={14} />
                        Aprendices incompletos
                      </button>
                    )}
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <div className="w-12 h-12 bg-pink-50 rounded-lg flex items-center justify-center">
                      <Users className="text-pink-600" size={24} />
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setIsEditCuotaOpen(true)}
                      className="text-gray-500 hover:text-gray-700"
                    >
                      <Edit2 size={14} className="mr-1" />
                      Editar
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Aprendices Table */}
          <Card className="border border-gray-200">
            <CardContent className="p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">
                Listado de Aprendices
              </h2>
              <div className="overflow-x-auto">
                {loading ? (
                  <div className="text-center py-8">
                    <p className="text-gray-600">Cargando aprendices...</p>
                  </div>
                ) : aprendices.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-gray-600">No hay aprendices en seguimiento</p>
                  </div>
                ) : (
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-200">
                        <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                          Nombre
                        </th>
                        <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                          Etapa
                        </th>
                        <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                          Programa
                        </th>
                        <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                          Ciudad
                        </th>
                        <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                          Inicio Contrato
                        </th>
                        <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                          Inicio Productiva
                        </th>
                        <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                          Fin Contrato
                        </th>
                        <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                          Reemplazo
                        </th>
                        <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                          Dias Restantes
                        </th>
                        <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                          Acciones
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {aprendices.map((aprendiz) => {
                        const diasRestantes = calcularDiasRestantes(aprendiz.fechaFinContrato);
                        return (
                          <tr
                            key={aprendiz._id}
                            className="border-b border-gray-100 last:border-0 hover:bg-gray-50"
                          >
                            <td className="py-4 px-4 text-sm font-medium text-gray-900">
                              {aprendiz.nombre} {aprendiz.apellido}
                            </td>
                            <td className="py-4 px-4">
                              <Badge
                                className={`${getEtapaBadgeStyle(
                                  aprendiz.etapaActual
                                )} rounded-full px-3 py-1 text-xs font-medium flex items-center w-fit`}
                              >
                                {getEtapaIcon(aprendiz.etapaActual)}
                                {aprendiz.etapaActual === 'lectiva'
                                  ? 'Lectiva'
                                  : aprendiz.etapaActual === 'productiva'
                                  ? 'Productiva'
                                  : 'Finalizado'}
                              </Badge>
                            </td>
                            <td className="py-4 px-4 text-sm text-gray-600">
                              {aprendiz.programa || '-'}
                            </td>
                            <td className="py-4 px-4 text-sm text-gray-600">
                              {aprendiz.ciudad || '-'}
                            </td>
                            <td className="py-4 px-4 text-sm text-gray-600">
                              {formatDate(aprendiz.fechaInicioContrato)}
                            </td>
                            <td className="py-4 px-4 text-sm text-gray-600">
                              {formatDate(aprendiz.fechaInicioProductiva)}
                            </td>
                            <td className="py-4 px-4 text-sm text-gray-600">
                              {formatDate(aprendiz.fechaFinContrato)}
                            </td>
                            <td className="py-4 px-4 text-sm text-blue-600">
                              {aprendiz.reemplazo
                                ? `${aprendiz.reemplazo.nombre} ${aprendiz.reemplazo.apellido}`
                                : '-'}
                            </td>
                            <td className="py-4 px-4 text-sm">
                              <span
                                className={`${
                                  diasRestantes < 0
                                    ? 'text-red-600'
                                    : diasRestantes <= 30
                                    ? 'text-amber-600'
                                    : 'text-gray-600'
                                }`}
                              >
                                {diasRestantes !== '-' ? `${diasRestantes} dias` : '-'}
                              </span>
                            </td>
                            <td className="py-4 px-4">
                              <div className="flex items-center gap-1">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleVerAprendiz(aprendiz)}
                                  className="text-gray-600 hover:text-gray-900 hover:bg-gray-100 p-2"
                                >
                                  <Eye size={16} />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleEditarAprendiz(aprendiz)}
                                  className="text-gray-600 hover:text-gray-900 hover:bg-gray-100 p-2"
                                >
                                  <Edit2 size={16} />
                                </Button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Modals */}
      <EditCuotaModal
        open={isEditCuotaOpen}
        onOpenChange={setIsEditCuotaOpen}
        cuotaActual={estadisticas.cuota}
        onSuccess={refetchEstadisticas}
      />

      <AprendicesIncompletosModal
        open={isIncompletosOpen}
        onOpenChange={setIsIncompletosOpen}
      />
    </>
  );
};

export default SeguimientoPage;
