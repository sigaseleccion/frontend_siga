import React from "react";

const SeguimientoPage = () => {
  return (
    <h1>Seguimiento</h1>
  );
};

export default SeguimientoPage;
