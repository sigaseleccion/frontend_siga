import React from "react";

const HistoricoAprendicesPage = () => {
  return (
    <h1>Historico de aprendices</h1>
  );
};

export default HistoricoAprendicesPage;