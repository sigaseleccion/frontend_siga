export { seguimientoService } from './seguimientoService';
